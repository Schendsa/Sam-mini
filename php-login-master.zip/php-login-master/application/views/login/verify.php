<div class="content">
    <h1>Verification</h1>

    <!-- echo out the system feedback (error and success messages) -->
    <?php $this->renderFeedbackMessages(); ?>

    <a href="<?php echo URL; ?>login/index">Go to login</a>
</div>
